const express = require("express");
const fs = require("fs");
const app = express();
const PORT = 9000;

app.use(express.json()); // Middleware to parse JSON

app.post("/webhook", (req, res) => {
  const newData = req.body;

  // Read existing data or start fresh
  let existingData = [];
  if (fs.existsSync("data.json")) {
    const raw = fs.readFileSync("data.json");
    existingData = JSON.parse(raw);
  }

  // Append new data
  existingData.push(newData);

  // Save to file
  fs.writeFileSync("data.json", JSON.stringify(existingData, null, 2));

  res.status(200).send({ message: "Data received and saved." });
});

app.listen(PORT, () => {
  console.log(`Webhook listening on http://localhost:${PORT}/webhook`);
});
