/* customview.js */

require([
  "splunkjs/mvc",
  "/static/app/customviewtutorial/demoview.js",
  "splunkjs/mvc/searchmanager",
  "splunkjs/mvc/textinputview",
  "splunkjs/mvc/simplexml/ready!",
], function (
  // Keep these variables in the same order as the libraries above:
  mvc,
  DemoView,
  SearchManager,
  TextInputView
) {
  // Create a text input for the number of artists to show
  var myTextBox = new TextInputView({
    id: "txtNum",
    value: mvc.tokenSafe("$headNum$"),
    default: "10",
    el: $("#txtNum"),
  }).render();

  // Set up the search managers

  // Downloads per artist
  var mySearch1 = new SearchManager({
    id: "mysearch1",
    preview: true,
    cache: true,
    search: mvc.tokenSafe(
      "| inputlookup musicdata.csv | search bc_uri=/sync/addtolibrary* | stats count by artist_name | table artist_name, count | head $headNum$"
    ),
  });

  // Searches on artist
  var mySearch2 = new SearchManager({
    id: "mysearch2",
    cache: true,
    search: mvc.tokenSafe(
      "| inputlookup musicdata.csv | search bc_uri=/browse/search* | stats count by search_terms | table search_terms, count | head $headNum$"
    ),
  });

  // Create the custom views for each search

  // Custom view showing search1
  var customView1 = new DemoView({
    id: "mycustomview1",
    managerid: "mysearch1",
    el: $("#mycustomview1"),
  }).render();

  // Custom view showing search2
  var customView2 = new DemoView({
    id: "mycustomview2",
    managerid: "mysearch2",
    el: $("#mycustomview2"),
  }).render();
});
