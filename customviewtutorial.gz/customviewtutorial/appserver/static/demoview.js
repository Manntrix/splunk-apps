/* demoview.js */

define(function (require, exports, module) {
  // Base class for custom views
  var SimpleSplunkView = require("splunkjs/mvc/simplesplunkview");

  // Require Underscore.js to work with search results
  var _ = require("underscore");

  // Require the Chart.js library for the radar chart
  var chart = require("/static/app/customviewtutorial/chart.js");

  // Define the custom view class
  var DemoView = SimpleSplunkView.extend({
    className: "demoview",

    // Define our initial values, set the type of results to return
    options: {
      maxDload: 0, // Chart scale
      mychartid: "", // ID for the chart
      data: "results", // Results type
    },

    // Override this method to configure the view
    createView: function () {
      // Create a unique chart ID based on the view's unique ID
      mychartid = this.name + "-radar";
      this.$el.html(
        '<canvas id="' + mychartid + '" width="700" height="700"></canvas>'
      );
      return this;
    },

    // Override this method to format the data for the radar chart
    formatData: function (data) {
      // The data object contains the search results
      var chartLabels = [];
      var chartData = [];
      maxDload = 0;

      // Populate the chart (labels, data) with the search result data
      _.each(data, function (row, i) {
        chartLabels[i] = row[0];
        chartData[i] = parseInt(row[1]) + 1;
        // Determine what the top download number is to set the chart scale
        if (chartData[i] > maxDload) {
          maxDload = chartData[i];
        }
      });

      // Set the radar chart data
      var radarChartData = {
        labels: chartLabels,
        datasets: [
          {
            fillColor: "rgba(151,187,205,0.5)",
            strokeColor: "rgba(151,187,205,1)",
            pointColor: "rgba(151,187,205,1)",
            pointStrokeColor: "#fff",
            data: chartData,
          },
        ],
      };

      return radarChartData;
    },

    // Override this method to put the Splunk data into the view
    updateView: function (viz, radarData) {
      // Set radar chart options
      var radarOptions = {
        scaleOverride: true,
        scaleSteps: maxDload,
        scaleStepWidth: 1,
        scaleStartValue: 0,
        scaleShowLabels: true,
        scaleShowLabelBackdrop: false,
      };

      // Create the radar chart
      var myRadar = new Chart(
        document.getElementById(mychartid).getContext("2d")
      ).Radar(radarData, radarOptions);
    },
  });

  return DemoView;
});
