# Certificate Monitoring Add-on for Splunk
=========================================

**Author:** Manish Mandal

---

## 📘 Description

The **Certificate Monitoring Add-on for Splunk** enables Splunk Enterprise and Splunk Cloud administrators to monitor SSL/TLS certificates from:

- Remote HTTPS endpoints (hostname:port)
- Remote servers via SSH (certificate files on disk)

The add-on is built using the Splunk Add-on Builder (AOB/UCC framework) and focuses on:

- Lightweight execution  
- Flexible data collection (HTTPS + SSH modes)  
- Structured JSON output for easy searching and alerting  

It is designed for scalable environments and can handle a large number of monitored endpoints efficiently.

---

## 🚀 Key Features

- Dual collection modes:
  - **HTTPS mode** → Fetch certificate from live endpoint  
  - **SSH mode** → Read certificate file from remote server  

- No external dependencies for HTTPS mode  
- Optional SSH support (Paramiko or system SSH)  
- Certificate parsing using Python standard library  
- JSON output for easy indexing and searching in Splunk  
- Scalable architecture supporting thousands of inputs  

---

## 📊 Fields Collected

### 🔹 General
- `time` – Timestamp of collection (UTC)
- `stanza` – Input stanza name
- `collection_mode` – `https` or `ssh`

---

### 🔹 Certificate Details
- `expiry_date` – Certificate expiration date
- `not_before` – Certificate valid-from date
- `days_left` – Days remaining before expiry
- `serial_number` – Certificate serial number

---

### 🔹 Subject Information
- `subject_cn` – Common Name (CN)
- `subject_o` – Organization Name (O)

---

### 🔹 Issuer Information
- `issuer_cn` – Issuer Common Name
- `issuer_o` – Issuer Organization

---

### 🔹 Subject Alternative Names (SAN)
- `subject_alt_names` – List of SAN entries

---

### 🔹 TLS Details (HTTPS Mode Only)
- `tls_version` – TLS protocol version
- `cipher` – Cipher suite name
- `cipher_protocol` – Cipher protocol version
- `cipher_bits` – Encryption strength

---

### 🔹 Connection Details

#### HTTPS Mode
- `hostname`
- `port`

#### SSH Mode
- `ssh_host`
- `ssh_port`
- `ssh_connection`
- `cert_path`

---

## 🧾 Example Event

```json
{
  "time": "2026-03-25 10:30:12 UTC",
  "collection_mode": "https",
  "hostname": "example.com",
  "port": "443",
  "expiry_date": "2026-06-20 12:00:00 UTC",
  "not_before": "2025-06-20 12:00:00 UTC",
  "days_left": 87,
  "subject_cn": "example.com",
  "issuer_cn": "Let's Encrypt Authority X3",
  "subject_alt_names": ["example.com", "www.example.com"],
  "tls_version": "TLSv1.3",
  "cipher": "TLS_AES_256_GCM_SHA384",
  "cipher_bits": "256"
}