[certificate_monitoring://<n>]
collection_mode = Collection mode: https or ssh
interval       = How often to check the certificate in seconds
hostname       = Hostname or IP address for HTTPS mode
port           = TCP port for HTTPS mode (default: 443)
ssh_connection = SSH connection name from Configuration > SSH Connections (SSH mode only)
cert_path      = Absolute path to the certificate file on the remote server (SSH mode only)
