[<connection_name>]
ssh_host           = Hostname or IP of the SSH server
ssh_port           = SSH port (default: 22)
ssh_user           = SSH username
ssh_password       = SSH password (encrypted)
ssh_key_path       = Absolute path to the private key file on the Splunk server
ssh_key_passphrase = Passphrase for the encrypted private key (encrypted)
