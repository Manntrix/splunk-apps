[tdc_custom_chart_default]
# Declare properties here
display.visualizations.custom.tdc_custom_chart.tdc.dataType = <string>
display.visualizations.custom.tdc_custom_chart.tdc.option = <string>
display.visualizations.custom.tdc_custom_chart.tdc.xAxisDataIndexBinding = <string>
display.visualizations.custom.tdc_custom_chart.tdc.seriesDataIndexBinding = <string>
display.visualizations.custom.tdc_custom_chart.tdc.jsHook= <string>
display.visualizations.custom.tdc_custom_chart.tdc.seriesColorDataIndexBinding= <string>
