[vault_snapshot://<name>]
index = (Default: password_vault)
interval = Seconds between snapshots (3600 = hourly). (Default: 3600)
