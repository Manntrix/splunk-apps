[master]
audit_index = 
auto_hide_seconds = 
lockout_minutes = 
master_password = 
max_failed_attempts = 
old_master_password = 

[backup]

[logging]
loglevel = 
